import sys
import asyncio
import socket

from main import async_input

def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip

async def launcher():
    print("Выберите режим:")
    print("1. Хост")
    print("2. Клиент")
    choice = (await async_input("Введите 1 или 2: ")).strip()
    if choice == '1':
        # Host
        ip = '0.0.0.0'
        port = 8766
        status = 'host'
        local_ip = get_local_ip()
        print(f"Запуск как хост. Ваш IP для подключения клиентов: {local_ip}")
        sys.argv = ['main.py', ip, str(port), status]
        import main
        await main.main()
    elif choice == '2':
        # Client
        host_ip = await async_input("Введите IP хоста: ")
        port = 8766
        status = 'client'
        sys.argv = ['main.py', host_ip, str(port), status]
        import main
        await main.main()
    else:
        print("Неверный выбор")

    # Keep console open
    await async_input("Нажмите Enter для выхода...")

if __name__ == "__main__":
    asyncio.run(launcher())
